Services: To run this example you will need to upload Counter.php into your servers amfphp/services/ folder.
Flash CS3: Update the remote gateway url in the main.as file before you run the Counter.fla
Flex 2: Example yet to be completed. 