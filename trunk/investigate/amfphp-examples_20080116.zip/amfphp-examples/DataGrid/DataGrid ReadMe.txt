Services: To run this example you will need to upload DataGrid.php into your servers amfphp/services/ folder.
Flash CS3: Update the remote gateway url in the main.as file before you run the Counter.fla
Flex 2: Example yet to be completed. 

TODO: Add method to update the dataset array. 
TODO: Add an additional call that shows how to get data from a database. 
TODO: Add a method to update the database dataset. 